#include <stdio.h>
int main(void) {
	int a, b, �, d, x, y, z=2;
	a=b;
	b=2;
	c=a+b;
	d=a*b;
	if (c=d) {
		x=100;
		y=200;
	} else {
		x=200;
		y=100;
	}
	printf("%d %d\n",x,y);
	return 0;
}
