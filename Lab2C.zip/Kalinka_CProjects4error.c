#include <stdio.h>
int main(void) {
	int a, b, c, d, x, y;
	a=1; abc();
	b=2;
	c=a+b;
	d=a*b;
	if (c==d) {
		x=100;
		y=200;
	} else {
		x=200;
		y=100;
	}
	printf("%d %d\n",x,y);
	return 0;
}
